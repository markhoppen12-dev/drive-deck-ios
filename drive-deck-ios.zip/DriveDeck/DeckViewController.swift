import CoreLocation
import UIKit
import WebKit

/// Shows the Drive Deck page full screen.
/// The page is loaded from the app bundle with the base address
/// https://appassets.androidplatform.net/ (the same address the Android app uses),
/// which gives it a secure origin for GPS and saved settings, and one website
/// address to allow on the Google Maps key for both phones.
final class DeckViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private static let base = URL(string: "https://appassets.androidplatform.net/")!
    private static let ink = UIColor(red: 11 / 255, green: 18 / 255, blue: 32 / 255, alpha: 1)

    private var web: WKWebView!
    private let location = CLLocationManager()

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.websiteDataStore = .default()
        config.applicationNameForUserAgent = "DriveDeck/1.0"

        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.isOpaque = false
        web.backgroundColor = Self.ink
        web.scrollView.backgroundColor = Self.ink
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.bounces = false
        web.allowsBackForwardNavigationGestures = false
        view = web
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Self.ink
        // Ask for location up front so the map's location button works first time.
        location.requestWhenInUseAuthorization()
        loadDeck()
    }

    private func loadDeck() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "web"),
              let html = try? String(contentsOf: url, encoding: .utf8) else { return }
        web.loadHTMLString(html, baseURL: Self.base)
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { .bottom }

    // MARK: Links

    /// Drive Deck's own page stays here; Google Maps, Waze, Apple Maps and phone
    /// links open in their own apps. Embedded maps inside the page load normally.
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { return decisionHandler(.allow) }
        let isMainFrame = navigationAction.targetFrame?.isMainFrame ?? true
        let scheme = url.scheme?.lowercased() ?? ""

        if !isMainFrame || ["about", "blob", "data"].contains(scheme) || url.host == Self.base.host {
            return decisionHandler(.allow)
        }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        decisionHandler(.cancel)
    }

    /// Links that ask for a new window (target="_blank") also open outside.
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        return nil
    }

    /// If iOS frees the page's memory in the background, reload it.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        loadDeck()
    }
}
